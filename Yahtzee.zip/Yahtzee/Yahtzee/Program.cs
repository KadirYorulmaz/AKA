﻿using YahtzeeGame.Services;

Random randomNumber = new Random();
randomNumber.Next(1, 6);

var diceArray = new int[5];

for(var i = 0; i < 5; i++)
{
    diceArray[i] = randomNumber.Next(1, 6);
}

Console.WriteLine($"Your dice: {string.Join(',', diceArray)}");
var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();
Console.WriteLine($"Chance: {yahtzeeCombinationCalculator.Chance(diceArray)}");
Console.WriteLine($"Yahtzee: {yahtzeeCombinationCalculator.Yahtzee(diceArray)}");
Console.WriteLine($"Ones: {yahtzeeCombinationCalculator.Ones(diceArray)}");
Console.WriteLine($"Twos: {yahtzeeCombinationCalculator.Twos(diceArray)}");
Console.WriteLine($"Threes: {yahtzeeCombinationCalculator.Threes(diceArray)}");
Console.WriteLine($"Fours: {yahtzeeCombinationCalculator.Fours(diceArray)}");
Console.WriteLine($"Fives: {yahtzeeCombinationCalculator.Fives(diceArray)}");
Console.WriteLine($"Sixes: {yahtzeeCombinationCalculator.Sixes(diceArray)}");
Console.WriteLine($"ScorePair: {yahtzeeCombinationCalculator.ScorePair(diceArray)}");
Console.WriteLine($"TwoPair: {yahtzeeCombinationCalculator.TwoPair(diceArray)}");
Console.WriteLine($"FourOfAKind: {yahtzeeCombinationCalculator.FourOfAKind(diceArray)}");
Console.WriteLine($"ThreeOfAKind: {yahtzeeCombinationCalculator.ThreeOfAKind(diceArray)}");
Console.WriteLine($"SmallStraight: {yahtzeeCombinationCalculator.SmallStraight(diceArray)}");
Console.WriteLine($"LargeStraight: {yahtzeeCombinationCalculator.LargeStraight(diceArray)}");
Console.WriteLine($"FullHouse: {yahtzeeCombinationCalculator.FullHouse(diceArray)}");











//var y = new Yahtzee(diceArray);

//public class Yahtzee
//{
//    private int[] _dice;
//    public Yahtzee(int[] dice)
//    {
//        _dice = dice;
//    }
//}
