﻿namespace YahtzeeGame.Interfaces
{
    public interface IYahtzeeCombinationCalculator
    {
        public int Chance(int[] dice);
        public int Yahtzee(int[] dice);
        public int Ones(int[] dice);
        public int Twos(int[] dice);
        public int Threes(int[] dice);
        public int Fours(int[] dice);
        public int Fives(int[] dice);
        public int Sixes(int[] dice);
        public int ScorePair(int[] dice);
        public int TwoPair(int[] dice);
        public int FourOfAKind(int[] dice);
        public int ThreeOfAKind(int[] dice);
        public int SmallStraight(int[] dice);
        public int LargeStraight(int[] dice);
        public int FullHouse(int[] dice);
    }
}
