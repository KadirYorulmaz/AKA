﻿using YahtzeeGame.Helper;
using YahtzeeGame.Interfaces;

namespace YahtzeeGame.Services
{
    public class YahtzeeCombinationCalculator : IYahtzeeCombinationCalculator
    {
        public int Chance(int[] dice)
        {
            return CombinationHelper.SumDice(dice);
        }

        public int Yahtzee(int[] dice)
        {
            var isDiceIdentical = CombinationHelper.AllDiceIdentical(dice);
            if (isDiceIdentical) return 50;

            return 0;
        }

        public int Ones(int[] dice)
        {
            int givenNumber = 1;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int Twos(int[] dice)
        {
            int givenNumber = 2;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int Threes(int[] dice)
        {
            int givenNumber = 3;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int Fours(int[] dice)
        {
            int givenNumber = 4;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int Fives(int[] dice)
        {
            int givenNumber = 5;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int Sixes(int[] dice)
        {
            int givenNumber = 6;
            return CombinationHelper.CountDiceIfGivenNumber(dice, givenNumber);
        }

        public int ScorePair(int[] dice)
        {
            var scorePair = CombinationHelper.FindHighestPair(dice);
            return scorePair * 2;
        }

        public int TwoPair(int[] dice)
        {
            var dicePair = CombinationHelper.GetHighestTwoPairs(dice);

            if (dicePair.Length == 2) return dicePair.Sum(b => b) * 2;
            
            return 0;
        }

        public int FourOfAKind(int[] dice)
        {
            return CombinationHelper.SumDiceIfDiceGivenNumberOfTimesOccured(dice, 4);
        }

        public int ThreeOfAKind(int[] dice)
        {
            return CombinationHelper.SumDiceIfDiceGivenNumberOfTimesOccured(dice, 3);
        }

        public int SmallStraight(int[] dice)
        {
            var smallStraight = new int[] { 1, 2, 3, 4, 5 };
            var isSmallStraight = CombinationHelper.CheckDiceSetEqualsStraightSet(dice, smallStraight);

            return isSmallStraight ? 15 : 0;
        }

        public int LargeStraight(int[] dice)
        {
            var largeStraight = new int[] { 2, 3, 4, 5, 6 };
            var isLargeStraight = CombinationHelper.CheckDiceSetEqualsStraightSet(dice, largeStraight);

            return isLargeStraight ? 20 : 0;
        }

        public int FullHouse(int[] dice)
        {
            var pairOfThree = dice.GroupBy(d => d).FirstOrDefault(g => g.Count() == 3)?.Key ?? 0;

            if (pairOfThree is 0)
            {
                return 0;
            }

            var pairOfTwo = dice.Where(g => g != pairOfThree).GroupBy(d => d).FirstOrDefault(g => g.Count() == 2)?.Key ?? 0;

            if (pairOfTwo is 0)
            {
                return 0;
            }

            return pairOfTwo * 2 + pairOfThree * 3;
        }        
    }
}
