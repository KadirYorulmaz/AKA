﻿
namespace YahtzeeGame.Helper
{
    public static class CombinationHelper
    {
        public static int CountDiceIfGivenNumber(int[] dice, int givenNumber)
        {
            return dice.Count(d => d == givenNumber) * givenNumber;
        }

        public static int SumDice(int[] dice)
        {
            return dice.Sum();
        }

        public static bool AllDiceIdentical(int[] dice)
        {
            var firstDice = dice[0];
            return dice.All(x => x == firstDice);
        }

        public static int FindHighestPair(int[] dice)
        {
            return dice
            .GroupBy(x => x)
            .Where(g => g.Count() == 2)
            .Max(g => (int?)g.Key) ?? 0;
        }

        public static int SumDiceIfDiceGivenNumberOfTimesOccured(int[] dice, int givenNumber)
        {
            var givenNumberOfAKinde = dice.GroupBy(x => x).FirstOrDefault(g => g.Count() == givenNumber);
            return givenNumberOfAKinde?.Sum() ?? 0;
        }

        public static int[] GetHighestTwoPairs(int[] dice)
        {
            return dice
            .GroupBy(x => x)
            .Where(g => g.Count() == 2)
            .OrderByDescending(g => g.Key)
            .Select(g => g.Key)
            .Take(2)
            .ToArray() 
            ?? 
            Array.Empty<int>();
        }

        public static bool CheckDiceSetEqualsStraightSet(int[] dice, int[] straightSet)
        {
            return straightSet.OrderBy(x => x).SequenceEqual(dice.OrderBy(x => x));
        }
    }
}
