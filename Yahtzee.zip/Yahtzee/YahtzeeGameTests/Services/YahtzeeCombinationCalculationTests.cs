﻿using YahtzeeGame.Services;

namespace YahtzeeGameTests.Services
{
    public class YahtzeeCombinationCalculationTests
    {
        [Theory]
        [InlineData(new int[] { 1, 2, 3, 4, 5 }, 15)]
        [InlineData(new int[] { 3, 2, 3, 4, 6 }, 18)]
        public void Chance_scores_sum_of_all_dice(int[] dice, int expected)
        {
            // Arrange 
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act 
            int result = yahtzeeCombinationCalculator.Chance(dice);

            // Assert 
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 1, 2, 3, 4, 5 }, 0)]
        [InlineData(new int[] { 4, 4, 4, 4, 4 }, 50)]
        [InlineData(new int[] { 6, 6, 6, 6, 6 }, 50)]
        public void Yahtzee_scores_50(int[] dice, int expected)
        {
            // Arrange 
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Yahtzee(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 1, 2, 3, 4, 5 }, 1)]
        [InlineData(new int[] { 1, 2, 1, 4, 5 }, 2)]
        [InlineData(new int[] { 6, 2, 2, 4, 5 }, 0)]
        [InlineData(new int[] { 1, 2, 1, 1, 1 }, 4)]
        public void Test_1s(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Ones(dice);

            // Assert
            Assert.True(result == expected);
            Assert.Equal(expected, result);

        }

        [Theory]
        [InlineData(new int[] { 1, 2, 3, 2, 6 }, 4)]
        [InlineData(new int[] { 2, 2, 2, 2, 2 }, 10)]
        public void test_2s(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Twos(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 1, 2, 3, 2, 3 }, 6)]
        [InlineData(new int[] { 2, 3, 3, 3, 3 }, 12)]
        public void test_threes(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Threes(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 4, 4, 4, 5, 5 }, 12)]
        [InlineData(new int[] { 4, 4, 5, 5, 5 }, 8)]
        [InlineData(new int[] { 4, 5, 5, 5, 5 }, 4)]
        public void fours_test(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Fours(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 4, 4, 4, 5, 5 }, 10)]
        [InlineData(new int[] { 4, 4, 5, 5, 5 }, 15)]
        [InlineData(new int[] { 4, 5, 5, 5, 5 }, 20)]
        public void fives(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Fives(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 4, 4, 4, 5, 5 }, 0)]
        [InlineData(new int[] { 4, 4, 6, 5, 5 }, 6)]
        [InlineData(new int[] { 6, 5, 6, 6, 5 }, 18)]
        public void sixes_test(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.Sixes(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 3, 4, 3, 5, 6 }, 6)]
        [InlineData(new int[] { 5, 3, 3, 3, 5 }, 10)]
        [InlineData(new int[] { 5, 3, 6, 6, 5 }, 12)]
        public void one_pair(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.ScorePair(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 3, 3, 5, 4, 5 }, 16)]
        [InlineData(new int[] { 3, 3, 1, 2, 5 }, 0)]
        public void two_Pair(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.TwoPair(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 3, 3, 3, 4, 5 }, 9)]
        [InlineData(new int[] { 5, 3, 5, 4, 5 }, 15)]
        [InlineData(new int[] { 3, 3, 2, 1, 5 }, 0)]
        public void three_of_a_kind(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.ThreeOfAKind(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 3, 3, 3, 3, 5 }, 12)]
        [InlineData(new int[] { 5, 5, 5, 4, 5 }, 20)]
        [InlineData(new int[] { 2, 5, 3, 3, 3 }, 0)]
        public void four_of_a_kind(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.FourOfAKind(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 1, 2, 3, 4, 5 }, 15)]
        [InlineData(new int[] { 2, 3, 4, 5, 1 }, 15)]
        [InlineData(new int[] { 1, 2, 2, 4, 5 }, 0)]
        [InlineData(new int[] { 2, 3, 4, 5, 6 }, 0)]
        public void smallStraight(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.SmallStraight(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 6, 2, 3, 4, 5 }, 20)]
        [InlineData(new int[] { 2, 3, 4, 5, 6 }, 20)]
        [InlineData(new int[] { 1, 2, 2, 4, 5 }, 0)]
        [InlineData(new int[] { 1, 2, 3, 4, 5 }, 0)]
        public void largeStraight(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.LargeStraight(dice);

            // Assert
            Assert.Equal(expected, result);
        }

        [Theory]
        [InlineData(new int[] { 6, 2, 2, 2, 6}, 18)]
        [InlineData(new int[] { 2, 3, 4, 5, 6 }, 0)]
        public void fullHouse(int[] dice, int expected)
        {
            // Arrange
            var yahtzeeCombinationCalculator = new YahtzeeCombinationCalculator();

            // Act
            int result = yahtzeeCombinationCalculator.FullHouse(dice);

            // Assert
            Assert.Equal(expected, result);
        }
    }
}
